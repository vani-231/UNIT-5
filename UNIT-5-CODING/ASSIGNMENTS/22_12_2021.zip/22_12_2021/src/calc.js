function add(a,b){
    return a+b
}

function mult(a,b){return a*b}

export {add,mult}
